<?php
/**
 * Created by PhpStorm.
 * User: tonypiton
 * Date: 04/02/2018
 * Time: 13:52
 */

class Model extends BDD
{
    /** Attributes **/


    /** Methods **/
    public function __construct()
    {
        parent::__construct();
    }
}