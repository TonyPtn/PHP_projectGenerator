<?php
/**
 * Created by PhpStorm.
 * User: tonypiton
 *
 * Desc : Model class for home page
 */

class Model extends BDD
{
    /** Attributes **/


    /** Methods **/
    /**
     * Model class constructor
     */
    public function __construct()
    {
        parent::__construct();
    }
}
